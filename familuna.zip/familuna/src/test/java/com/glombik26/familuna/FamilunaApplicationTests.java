package com.glombik26.familuna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FamilunaApplicationTests {

	@Test
	void contextLoads() {
	}

}
