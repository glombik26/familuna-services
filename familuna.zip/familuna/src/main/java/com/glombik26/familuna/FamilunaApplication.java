package com.glombik26.familuna;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FamilunaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FamilunaApplication.class, args);
	}

}
